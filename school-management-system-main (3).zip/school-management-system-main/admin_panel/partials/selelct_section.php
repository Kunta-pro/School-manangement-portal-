<option value="A">A</option>
<option value="B">B</option>
<option value="C">C</option>