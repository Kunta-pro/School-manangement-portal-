<?php include('shared/_header.php');?>

<body>
    <main>
        <div class="big-wrapper light">
            <img src="./images/shape.png" alt="" class="shape" />

            
     <?php include('shared/_navbar.php'); ?>



            <div class="container mt-5">


    
                <div class="card border-0 shadow about-card">
                    <div class="card-body mt-5 mb-2 mx-3 ">
                        <h3 class="card-title">
                        <span class="text-primary icon-hover"><i class="fa-solid fa-paperclip"></i></span>    
                        About us</h3>
                        <p class="card-text fs-5 text-justify">
                        Embark on your coding journey with courage and curiosity. Every line of code you write is a step toward creating something extraordinary. Embrace the challenges, for they will become the milestones of your progress. Remember, every expert was once a beginner. Keep learning, stay persistent, and let your passion guide you. Your potential is limitless.
                    </div>
                    <div class="mb-4" style="width: 100%;  display: flex; align-items: center; justify-content: center;">
                    <img style="width: 400px;"  src="./images/company-logo.png" class="card-img-bottom" alt="...">
                    </div>
                </div>


                
            </div>








        </div>


    </main>




  
    <?php include('shared/_footer.php'); ?>